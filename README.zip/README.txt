INSTRUCTION TO RUN APP:

1. install dependencies
2. run npm start
3. done

INSTRUCTION FOR JSON PATH


1. open gitbash then type 'pwd' on the directory where your JSON is
2. remove the /d or /c on when copying the path
3. pwd + path of you JSON = path to put in th directory
4. when putting json path format must like this `/Github/test/test/input.json`
5. done
